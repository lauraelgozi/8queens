import './../styles/main.css';
import Dom from './dom.js';

Dom.intialize()
